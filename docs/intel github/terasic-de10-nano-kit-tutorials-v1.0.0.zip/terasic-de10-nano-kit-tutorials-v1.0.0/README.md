# terasic-de10-nano-kit repository

This repository contains code examples and tutorials for use with the Terasic DE10-Nano development kit by Terasic Technologies Inc.  Please see the README files in each subdirectory for more details.

You can purchase a Terasic DE10-Nano development kit from Terasic Technologies Inc. [here][terasic-de10-nano-kit].

[terasic-de10-nano-kit]:https://www.buyaltera.com/PartDetail?partId=6817231&_ga=2.170836131.2082584067.1508344338-597743693.1508342407

